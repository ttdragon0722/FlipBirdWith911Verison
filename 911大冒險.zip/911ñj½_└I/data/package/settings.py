WIDTH = 600
HEIGHT = 800
FPS = 60

fonts_name = "data/font/BugMaruGothic.ttc"